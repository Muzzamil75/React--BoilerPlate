## Available Scripts

### Integrated Following

#### 1- Prop Types

#### 2- Sass

#### 3- Eslint

#### 4- Redux Thunk

#### 5- Project Structure

#### 6- Styled Component

#### 7- React-router-dom
