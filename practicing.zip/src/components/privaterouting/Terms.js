import React, { Component } from 'react'

export default class Terms extends Component {
  render() {
    return (
      <div>
        This is the public route of terms and condition page.
      </div>
    )
  }
}
